import webrtcvad
import pyaudio

def is_speaking():
    # VAD asosida gaplashayotganini aniqlash (soddalashtirilgan)
    return True