import cv2

def detect_face_yolo(frame):
    # Simulyatsiya sifatida har doim “ko‘rinmoqda” deb qaytaramiz
    # Aslida YOLOv8 ni Ultralytics orqali chaqirish mumkin
    return True
